
module.exports = app => {
    const films = require("../controllers/film.controller");
    const secured = require('../../secure');


    app.get('/film/',secured,films.findAllView);
    app.get('/film/:id',secured,films.findOneView);

    app.get('/json/film/',secured,films.findAll);
    app.get('/json/film/:id',secured,films.findOne);


};