
module.exports = app => {
    const films = require("../controllers/character.controller");
    const secured = require('../../secure');


    app.get('/character/',secured,films.findAllView);
    app.get('/character/:id',secured,films.findOneView);

    app.get('/json/character/',secured,films.findAll);
    app.get('/json/character/:id',secured,films.findOne);


};