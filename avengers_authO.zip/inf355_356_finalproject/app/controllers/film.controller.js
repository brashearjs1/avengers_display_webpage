const db = require("../model"); // models path depend on your structure
const Film = db.film;


exports.create = (req, res) => {
    // Validate request
    if (!req.body.film.film_id) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
        return;
    }

    // Create a Tutorial
    let d = req.body;
    const film = {
        Title: d.Title,
        Plot: d.Plot,
        Producer: d.Producer,
        Director: d.Director,
        ReleaseDate: d.ReleaseDate,
        ChronologicalTimeline: d.ChronologicalTimeline,

    };

    // Save Tutorial in the database
    Film.create(film)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while inserting film."
            });
        });
};

exports.findAll = (req,res) =>{
    Film.findAll()
        .then( data =>{
            console.log('data returned from findAll');
            res.setHeader('content-type','application/json');
            res.send(data);
        })
        .catch(err =>{
            res.status(500).send({
                    message:
                        err.message || "Some error occurred retrieving films"
                }
            );
        });
};

exports.findOne = (req,res) => {
    Film.findByPk(req.params.id)
        .then(data=>{
            console.log('data returned from find one: ', data.toJSON);
            res.setHeader('content-type','application/json');
            res.send(data);
        })
        .catch(err =>{
            res.status(500).send({
                message: 'Error retrieving film with film #:' +
                    req.params.id
            });
        });
}

exports.findOneView = (req,res) => {
    Film.findByPk(req.params.id)
        .then(data=>{

            res.render('find_all.pug',{resources: [data.toJSON()]});
        })
        .catch(err =>{
            res.status(500).send({
                message: 'Error retrieving film with film #:' +
                    req.params.id
            });
        });
}

exports.findAllView = (req,res) =>{
    Film.findAll({raw:true})
        .then( data =>{
            console.log('data returned from findAll');
            res.render('find_all.pug',{resources: data})
        })
        .catch(err =>{
            res.status(500).send({
                    message:
                        err.message || "Some error occurred retrieving films"
                }
            );
        });
};