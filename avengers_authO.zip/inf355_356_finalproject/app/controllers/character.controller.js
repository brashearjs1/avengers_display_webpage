const db = require("../model"); // models path depend on your structure
const Character = db.character;


exports.create = (req, res) => {
    // Validate request
    if (!req.body.film.film_id) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
        return;
    }

    // Create a Tutorial
    let d = req.body;
    const character = {
        Name: d.Name,
        HeroName: d.HeroName,
        Bio: d.Bio,
        Power: d.Power,
        HairColor: d.HairColor,
        Gender: d.Gender,
        FirstAppearance: d.FirstAppearance,

    };

    // Save Tutorial in the database
    Character.create(character)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while inserting character."
            });
        });
};

exports.findAll = (req,res) =>{
    Character.findAll()
        .then( data =>{
            console.log('data returned from findAll');
            res.setHeader('content-type','application/json');
            res.send(data);
        })
        .catch(err =>{
            res.status(500).send({
                    message:
                        err.message || "Some error occurred retrieving characters"
                }
            );
        });
};

exports.findOne = (req,res) => {
    Character.findByPk(req.params.id)
        .then(data=>{
            console.log('data returned from find one: ', data.toJSON);
            res.setHeader('content-type','application/json');
            res.send(data);
        })
        .catch(err =>{
            res.status(500).send({
                message: 'Error retrieving character with character #:' +
                    req.params.id
            });
        });
}

exports.findOneView = (req,res) => {
    Character.findByPk(req.params.id)
        .then(data=>{

            res.render('find_all.pug',{resources: [data.toJSON()]});
        })
        .catch(err =>{
            res.status(500).send({
                message: 'Error retrieving character with character #:' +
                    req.params.id
            });
        });
}

exports.findAllView = (req,res) =>{
    Character.findAll({raw:true})
        .then( data =>{
            console.log('data returned from findAll');
            res.render('find_all.pug',{resources: data})
        })
        .catch(err =>{
            res.status(500).send({
                    message:
                        err.message || "Some error occurred retrieving characters"
                }
            );
        });
};