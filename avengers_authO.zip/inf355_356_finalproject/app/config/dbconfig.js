module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "dennisiscool",
    DB: "avengers",
    PORT: 3306,
    dialect: 'mysql',
    operatorsAliases: 0,
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
};