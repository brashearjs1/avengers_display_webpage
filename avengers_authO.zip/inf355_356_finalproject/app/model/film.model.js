module.exports = (sequelize,Sequelize)=>{
    const Film = sequelize.define('films', {
        film_Id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        Title: {
            type: Sequelize.STRING,
        },
        Plot: {
            type: Sequelize.STRING,
        },
        Producer: {
            type: Sequelize.STRING,
        },
        Director: {
            type: Sequelize.STRING,
        },
        ReleaseDate: {
            type: Sequelize.STRING,
        },
        ChronologicalTimeline: {
            type: Sequelize.STRING,
        },

    },{
        timestamps: false


    });
    return Film;
}