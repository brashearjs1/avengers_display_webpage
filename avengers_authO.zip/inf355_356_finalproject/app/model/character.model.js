module.exports = (sequelize,Sequelize)=>{
    const Character = sequelize.define('characters', {
        character_Id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        Name: {
            type: Sequelize.STRING,
        },
        HeroName: {
          type: Sequelize.STRING,
        },
        Bio: {
            type: Sequelize.STRING,
        },
        Power: {
            type: Sequelize.STRING,
        },
        HairColor: {
            type: Sequelize.STRING,
        },
        Gender: {
            type: Sequelize.STRING,
        },
        FirstAppearance: {
            type: Sequelize.STRING,
        },

    },{
        timestamps: false


    });
    return Character;
}